//
//  RecordingsLibraryViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class RecordingsLibraryViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleButton: SupernovaButton!
    @IBOutlet weak var rectangleBlurView: UIView!
    @IBOutlet weak var rectangleTwoBlurView: UIView!
    @IBOutlet weak var rectangleThreeBlurView: UIView!
    @IBOutlet weak var rectangleFourBlurView: UIView!
    @IBOutlet weak var rectangleFiveBlurView: UIView!
    @IBOutlet weak var recordingsLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleButton
        self.rectangleButton.layer.cornerRadius = 6
        self.rectangleButton.layer.masksToBounds = true
        self.rectangleButton.snImageTextSpacing = 10
        
        // Setup rectangleBlurView
        self.rectangleBlurView.layer.cornerRadius = 6
        self.rectangleBlurView.layer.masksToBounds = true
        
        // Setup rectangleTwoBlurView
        self.rectangleTwoBlurView.layer.cornerRadius = 6
        self.rectangleTwoBlurView.layer.masksToBounds = true
        
        // Setup rectangleThreeBlurView
        self.rectangleThreeBlurView.layer.cornerRadius = 6
        self.rectangleThreeBlurView.layer.masksToBounds = true
        
        // Setup rectangleFourBlurView
        self.rectangleFourBlurView.layer.cornerRadius = 6
        self.rectangleFourBlurView.layer.masksToBounds = true
        
        // Setup rectangleFiveBlurView
        self.rectangleFiveBlurView.layer.cornerRadius = 6
        self.rectangleFiveBlurView.layer.masksToBounds = true
        
        // Setup recordingsLabel
        let recordingsLabelAttrString = NSMutableAttributedString(string: "Recordings", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.recordingsLabel.attributedText = recordingsLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onRectanglePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Recording Example", sender: nil)
    }
}
