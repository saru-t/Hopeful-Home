//
//  FGMOpenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class FGMOpenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var oftenForReligionLabel: UILabel!
    @IBOutlet weak var typesOfFgmLabel: UILabel!
    @IBOutlet weak var buttonButton: SupernovaButton!
    @IBOutlet weak var thereAre4DifferenLabel: UILabel!
    @IBOutlet weak var femaleGenitalMutilLabel: UILabel!
    @IBOutlet weak var fgmLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup oftenForReligionLabel
        let oftenForReligionLabelAttrString = NSMutableAttributedString(string: "Often for religion, hygiene, preservation of virginity, marriageability and enhancement of male sexual pleasure.\n\nFGM can cause severe bleeding and problems urinating, and later cysts, infections, as well as complications in childbirth and increased risk of newborn deaths.\n\nMore than 200 million girls and women alive today have been cut in 30 countries in Africa, the Middle East and Asia where FGM is concentrated (1).\nFGM is mostly carried out on young girls between infancy and age 15.\nFGM is a violation of the human rights of girls and women\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.44, green: 0.44, blue: 0.44, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.oftenForReligionLabel.attributedText = oftenForReligionLabelAttrString
        
        // Setup typesOfFgmLabel
        let typesOfFgmLabelAttrString = NSMutableAttributedString(string: "Types of FGM", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 21)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.typesOfFgmLabel.attributedText = typesOfFgmLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup thereAre4DifferenLabel
        let thereAre4DifferenLabelAttrString = NSMutableAttributedString(string: "There are 4 different types of FGM:\nType 1:  this is the partial or total removal of the clitoral glans (the external and visible part of the clitoris, which is a sensitive part of the female genitals), and/or the prepuce/ clitoral hood (the fold of skin surrounding the clitoral glans).\nType 2:  This is the partial or total removal of the clitoral glans and the labia minora (the inner folds of the vulva), with or without removal of the labia majora (the outer folds of skin of the vulva ).\nType 3: Also known as infibulation, this is the narrowing of the vaginal opening through the creation of a covering seal. The seal is formed by cutting and repositioning the labia minora, or labia majora, sometimes through stitching, with or without removal of the clitoral prepuce/clitoral hood and glans (Type I FGM).\nType 4: This includes all other harmful procedures to the female genitalia for non-medical purposes, e.g. pricking, piercing, incising, scraping and cauterizing the genital area.\n\nNHS Choices – Female Genital Mutilation\nFemale genital mutilation\nChildLineHelpline: 0800 1111 (24 hours)\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 21)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.thereAre4DifferenLabel.attributedText = thereAre4DifferenLabelAttrString
        
        // Setup femaleGenitalMutilLabel
        let femaleGenitalMutilLabelAttrString = NSMutableAttributedString(string: "Female genital mutilation (FGM) involves the partial or total removal of external female genitalia or other injury to the female genital organs for non-medical reasons OFTEN", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.39, green: 0.62, blue: 0.72, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.femaleGenitalMutilLabel.attributedText = femaleGenitalMutilLabelAttrString
        
        // Setup fgmLabel
        let fgmLabelAttrString = NSMutableAttributedString(string: "FGM", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.fgmLabel.attributedText = fgmLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onbuttonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM & H", sender: nil)
    }
}
