//
//  HelpfulInformationViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HelpfulInformationViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var legalInfoButton: SupernovaButton!
    @IBOutlet weak var helplinesButton: SupernovaButton!
    @IBOutlet weak var positivityButton: SupernovaButton!
    @IBOutlet weak var safetyButton: SupernovaButton!
    @IBOutlet weak var whatIsDvButton: SupernovaButton!
    @IBOutlet weak var fgmButton: SupernovaButton!
    @IBOutlet weak var youthCornerButton: SupernovaButton!
    @IBOutlet weak var helpfulInformationLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup legalInfoButton
        self.legalInfoButton.layer.cornerRadius = 12
        self.legalInfoButton.layer.masksToBounds = true
        self.legalInfoButton.snImageTextSpacing = 10
        
        // Setup helplinesButton
        self.helplinesButton.layer.cornerRadius = 12
        self.helplinesButton.layer.masksToBounds = true
        self.helplinesButton.snImageTextSpacing = 10
        
        // Setup positivityButton
        self.positivityButton.layer.cornerRadius = 12
        self.positivityButton.layer.masksToBounds = true
        self.positivityButton.snImageTextSpacing = 10
        
        // Setup safetyButton
        self.safetyButton.layer.cornerRadius = 12
        self.safetyButton.layer.masksToBounds = true
        self.safetyButton.snImageTextSpacing = 10
        
        // Setup whatIsDvButton
        self.whatIsDvButton.layer.cornerRadius = 12
        self.whatIsDvButton.layer.masksToBounds = true
        self.whatIsDvButton.snImageTextSpacing = 10
        
        // Setup fgmButton
        self.fgmButton.layer.cornerRadius = 12
        self.fgmButton.layer.masksToBounds = true
        self.fgmButton.snImageTextSpacing = 10
        
        // Setup youthCornerButton
        self.youthCornerButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.youthCornerButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.youthCornerButton.layer.shadowRadius = 4
        self.youthCornerButton.layer.shadowOpacity = 1
        
        self.youthCornerButton.layer.borderColor = UIColor(red: 0.471, green: 0.624, blue: 0.8, alpha: 1).cgColor /* #789FCC */
        self.youthCornerButton.layer.borderWidth = 2
        
        self.youthCornerButton.snImageTextSpacing = 10
        
        // Setup helpfulInformationLabel
        let helpfulInformationLabelAttrString = NSMutableAttributedString(string: "Helpful Information", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.helpfulInformationLabel.attributedText = helpfulInformationLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17TwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Closed", sender: nil)
    }

    @IBAction public func onGroup17ThreePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helplines", sender: nil)
    }

    @IBAction public func onGroup17FourPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Positivity", sender: nil)
    }

    @IBAction public func onGroup17FivePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Safety Plan Closed", sender: nil)
    }

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push What is DA", sender: nil)
    }

    @IBAction public func onGroup17SixPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push FGM & H", sender: nil)
    }

    @IBAction public func onRectanglePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Youth Corner", sender: nil)
    }
}
