//
//  LegalInformationOpenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class LegalInformationOpenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var relevantLawsSeriouLabel: UILabel!
    @IBOutlet weak var divorceButton: SupernovaButton!
    @IBOutlet weak var legalInformationLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup relevantLawsSeriouLabel
        let relevantLawsSeriouLabelAttrString = NSMutableAttributedString(string: "Relevant Laws\n\nSerious Crime Act 2015: Controlling or coercive behaviour in an intimate or family relationship (s76)\n\nAnti-Social Behaviour, Crime and Policing Act 2014: (s120-122)\n\nFemale Genital Mutilation Act 2003\n\nProtection from Harassment Act 1997\n\nCrime and Disorder Act 1998: Racially or religiously aggravated harassment etc.(s32)\n\nDomestic Violence\n\nCrime and Victims Act 2004: Restraining Orders (s12-13)\n", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 16)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.relevantLawsSeriouLabel.attributedText = relevantLawsSeriouLabelAttrString
        
        // Setup divorceButton
        self.divorceButton.layer.cornerRadius = 12
        self.divorceButton.layer.masksToBounds = true
        self.divorceButton.snImageTextSpacing = 10
        
        // Setup legalInformationLabel
        let legalInformationLabelAttrString = NSMutableAttributedString(string: "Legal Information", attributes: [
            .font : UIFont.systemFont(ofSize: 36),
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.legalInformationLabel.attributedText = legalInformationLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Divorce Process Closed", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
