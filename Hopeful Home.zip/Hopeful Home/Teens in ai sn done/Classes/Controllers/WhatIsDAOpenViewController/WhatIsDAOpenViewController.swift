//
//  WhatIsDAOpenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class WhatIsDAOpenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var governmentDefinitioLabel: UILabel!
    @IBOutlet weak var typesOfAbusePsycLabel: UILabel!
    @IBOutlet weak var physicalAbuseBeinLabel: UILabel!
    @IBOutlet weak var isolationLimitingLabel: UILabel!
    @IBOutlet weak var dropupButton: SupernovaButton!
    @IBOutlet weak var whatIsDomesticAbuLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup governmentDefinitioLabel
        let governmentDefinitioLabelAttrString = NSMutableAttributedString(string: "Government Definition: Any incident or pattern of incidents of controlling, coercive or threatening behaviour, violence or abuse from age 16+ who are/have been intimate partners or family members regardless of genfer or sexuality.", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.governmentDefinitioLabel.attributedText = governmentDefinitioLabelAttrString
        
        // Setup typesOfAbusePsycLabel
        let typesOfAbusePsycLabelAttrString = NSMutableAttributedString(string: "Types of abuse:\nPsychological\nPhysical\nSexual\nFinancial\nEmotional\n\n\nControlling Behaviour: make person dependnt on them by isolating them from sources of support.\nCoercive Behaviour: Pattern of assault, threats, humiliation and intimidation to frightn/harm vicim.\n", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.typesOfAbusePsycLabel.attributedText = typesOfAbusePsycLabelAttrString
        
        // Setup physicalAbuseBeinLabel
        let physicalAbuseBeinLabelAttrString = NSMutableAttributedString(string: "Physical Abuse: Being kicked, punched, pinched, slapped, choked and bitten. Threats/Use of weapons, being poisoned, objects thrown, violence to family members or pets.", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.physicalAbuseBeinLabel.attributedText = physicalAbuseBeinLabelAttrString
        
        // Setup isolationLimitingLabel
        let isolationLimitingLabelAttrString = NSMutableAttributedString(string: "Isolation: limiting outside involvement, not allowing any activity that doesn’t involve him/her. Checking your wherabouts constantly.\n\nVerbal Abuse: Constant yelling and shouring, verbal humiliation, constantly being made fun of, blaming you for their failures\n\nThreatening Behaviour: Threat of violence, threatening weapon use, threat to remove your children\n\nEmotional & Psychological: Intimidation, Withholding affection,turning friends against you, sopped from seeing relatives or friends, not letting you sleep, excessive contact, persuading you to doubt your sanity\n\nFinancial: Totally controlling family income, not allowing you to spend money unless ‘permitted’, making you account for every pound you spend, huge bills in your name without your knowlefge\n\nSexual: Sexual pressure, forcing sex after physical assualys, sexually degrading language, rape, forcing you to have sex\n\nDigital and Social Media Abuse: Stalking you, placing false information about you, being trolled, no control over your content, constant monitoring.\n\nFalse Allegations:  Telling(/threatening to tell) police/family/friends you are the one committing domestic abuse when it is the other way round.\n\nCoercive and Controlling Behaviour\nIsolating a person from friends and family, monitoring time/phone using spyware, controlling aspects of daily life, controlling cloths, depriving them from support", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.isolationLimitingLabel.attributedText = isolationLimitingLabelAttrString
        
        // Setup dropupButton
        self.dropupButton.snImageTextSpacing = 10
        
        // Setup whatIsDomesticAbuLabel
        let whatIsDomesticAbuLabelAttrString = NSMutableAttributedString(string: "What is Domestic Abuse?", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.whatIsDomesticAbuLabel.attributedText = whatIsDomesticAbuLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onbuttonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push What is DA", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
