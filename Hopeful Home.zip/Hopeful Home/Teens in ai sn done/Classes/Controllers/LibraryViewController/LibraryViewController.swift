//
//  LibraryViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class LibraryViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var yourDiaryButton: SupernovaButton!
    @IBOutlet weak var recordingsButton: SupernovaButton!
    @IBOutlet weak var storedImagesButton: SupernovaButton!
    @IBOutlet weak var yourLibraryLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup yourDiaryButton
        self.yourDiaryButton.layer.cornerRadius = 12
        self.yourDiaryButton.layer.masksToBounds = true
        self.yourDiaryButton.snImageTextSpacing = 10
        
        // Setup recordingsButton
        self.recordingsButton.layer.cornerRadius = 12
        self.recordingsButton.layer.masksToBounds = true
        self.recordingsButton.snImageTextSpacing = 10
        
        // Setup storedImagesButton
        self.storedImagesButton.layer.cornerRadius = 12
        self.storedImagesButton.layer.masksToBounds = true
        self.storedImagesButton.snImageTextSpacing = 10
        
        // Setup yourLibraryLabel
        let yourLibraryLabelAttrString = NSMutableAttributedString(string: "Your Library", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.yourLibraryLabel.attributedText = yourLibraryLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Diary Library", sender: nil)
    }

    @IBAction public func onGroup17TwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Recordings Library", sender: nil)
    }

    @IBAction public func onGroup17ThreePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Stored Images", sender: nil)
    }
}
