//
//  NewDiaryEntryViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class NewDiaryEntryViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var group9View: UIView!
    @IBOutlet weak var group9TwoView: UIView!
    @IBOutlet weak var group13View: UIView!
    @IBOutlet weak var clikHereToUploadCopyLabel: UILabel!
    @IBOutlet weak var group17Button: SupernovaButton!
    @IBOutlet weak var newDiaryEntryLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup group9View
        self.group9View.layer.borderColor = UIColor(red: 0.808, green: 0.824, blue: 0.851, alpha: 1).cgColor /* #CED2D9 */
        self.group9View.layer.borderWidth = 1
        
        self.group9View.layer.cornerRadius = 4
        self.group9View.layer.masksToBounds = true
        
        // Setup group9TwoView
        self.group9TwoView.layer.borderColor = UIColor(red: 0.808, green: 0.824, blue: 0.851, alpha: 1).cgColor /* #CED2D9 */
        self.group9TwoView.layer.borderWidth = 1
        
        self.group9TwoView.layer.cornerRadius = 4
        self.group9TwoView.layer.masksToBounds = true
        
        // Setup group13View
        self.group13View.layer.borderColor = UIColor(red: 0.808, green: 0.824, blue: 0.851, alpha: 1).cgColor /* #CED2D9 */
        self.group13View.layer.borderWidth = 2
        
        self.group13View.layer.cornerRadius = 4
        self.group13View.layer.masksToBounds = true
        
        // Setup clikHereToUploadCopyLabel
        let clikHereToUploadCopyLabelAttrString = NSMutableAttributedString(string: "Clik here to upload", attributes: [
            .font : UIFont.systemFont(ofSize: 14),
            .foregroundColor : UIColor(red: 0.38, green: 0.42, blue: 0.48, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: 21, paragraphSpacing: 0)
        ])
        self.clikHereToUploadCopyLabel.attributedText = clikHereToUploadCopyLabelAttrString
        
        // Setup group17Button
        self.group17Button.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.group17Button.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.group17Button.layer.shadowRadius = 4
        self.group17Button.layer.shadowOpacity = 1
        
        self.group17Button.layer.cornerRadius = 12
        self.group17Button.layer.masksToBounds = true
        self.group17Button.snImageTextSpacing = 10
        
        // Setup newDiaryEntryLabel
        let newDiaryEntryLabelAttrString = NSMutableAttributedString(string: "New Diary Entry", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.newDiaryEntryLabel.attributedText = newDiaryEntryLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return true
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Diary Library", sender: nil)
    }
}
