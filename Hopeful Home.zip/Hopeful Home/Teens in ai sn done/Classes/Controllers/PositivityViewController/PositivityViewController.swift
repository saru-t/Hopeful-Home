//
//  PositivityViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class PositivityViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var inYourDiaryForLabel: UILabel!
    @IBOutlet weak var quotesButton: SupernovaButton!
    @IBOutlet weak var tipsToStayPositivLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup inYourDiaryForLabel
        let inYourDiaryForLabelAttrString = NSMutableAttributedString(string: "\n1) In your diary,for today, only write about positive things and gratitude that have happened today. Studies have found gratitude to be linked with positive emotions and well-being.\n\n2) Listen to music that sounds the way you want to feel\n\n3) Do a kind act everyday  - kindness can boost happiness and reduce depression\n\n4) Challenge your negative thinking\n\n5) Smile - smiling makes you feel happier\n\n6) Meditate - 7 mins of meditation can improve mood, decrease stress and improve sleep.\n\n7) Try remember this: Breathe, Refocus\n\n8) Try to eat as well as possible\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.inYourDiaryForLabel.attributedText = inYourDiaryForLabelAttrString
        
        // Setup quotesButton
        self.quotesButton.layer.cornerRadius = 12
        self.quotesButton.layer.masksToBounds = true
        self.quotesButton.snImageTextSpacing = 10
        
        // Setup tipsToStayPositivLabel
        let tipsToStayPositivLabelAttrString = NSMutableAttributedString(string: "Tips to Stay Positive", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.tipsToStayPositivLabel.attributedText = tipsToStayPositivLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push PQ 1", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
