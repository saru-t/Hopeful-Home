//
//  PQ3ViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class PQ3ViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var previousButton: SupernovaButton!
    @IBOutlet weak var youReBraverThanLabel: UILabel!
    @IBOutlet weak var group17Button: SupernovaButton!
    @IBOutlet weak var nextButton: SupernovaButton!
    @IBOutlet weak var positiveQuotesLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup previousButton
        self.previousButton.snImageTextSpacing = 10
        
        // Setup youReBraverThanLabel
        let youReBraverThanLabelAttrString = NSMutableAttributedString(string: "“You're braver than you believe, and stronger than you seem, and smarter than you think.” ...\n", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 21)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.23,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.youReBraverThanLabel.attributedText = youReBraverThanLabelAttrString
        
        // Setup group17Button
        self.group17Button.layer.cornerRadius = 12
        self.group17Button.layer.masksToBounds = true
        self.group17Button.snImageTextSpacing = 10
        
        // Setup nextButton
        self.nextButton.snImageTextSpacing = 10
        
        // Setup positiveQuotesLabel
        let positiveQuotesLabelAttrString = NSMutableAttributedString(string: "Positive Quotes", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.positiveQuotesLabel.attributedText = positiveQuotesLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onLeftTwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push PQ 2", sender: nil)
    }

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Saved", sender: nil)
    }

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push PQ 4", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Positivity", sender: nil)
    }
}
