//
//  Information2ViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class Information2ViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleView: UIView!
    @IBOutlet weak var rectangleTwoView: UIView!
    @IBOutlet weak var importantInformatioLabel: UILabel!
    @IBOutlet weak var everyWeekThePasswLabel: UILabel!
    @IBOutlet weak var skipButton: SupernovaButton!
    @IBOutlet weak var next2Button: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.borderColor = UIColor(red: 0.686, green: 0.788, blue: 0.812, alpha: 1).cgColor /* #AFC9CF */
        self.rectangleView.layer.borderWidth = 8
        
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.rectangleTwoView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleTwoView.layer.shadowRadius = 4
        self.rectangleTwoView.layer.shadowOpacity = 1
        
        self.rectangleTwoView.layer.borderColor = UIColor(red: 0.686, green: 0.788, blue: 0.812, alpha: 1).cgColor /* #AFC9CF */
        self.rectangleTwoView.layer.borderWidth = 4
        
        
        // Setup importantInformatioLabel
        let importantInformatioLabelAttrString = NSMutableAttributedString(string: "Important Information", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 34)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.37,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.importantInformatioLabel.attributedText = importantInformatioLabelAttrString
        
        // Setup everyWeekThePasswLabel
        let everyWeekThePasswLabelAttrString = NSMutableAttributedString(string: "\nEvery week the password will regenerate. Don’t worry we’ll let you know! The current password will always be displayed under the logo\n\n\n\nHopeful Home can record audio discreetly behind the calculator screen.\n\n\nTo record: Click ‘see past calculations’ —> ‘record calculations’. Then when you’re done hit ‘stop recording calculations’\n\n\n\nFor immediate help - click see past calculations and press and hold 9\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.everyWeekThePasswLabel.attributedText = everyWeekThePasswLabelAttrString
        
        // Setup skipButton
        self.skipButton.snImageTextSpacing = 10
        
        // Setup next2Button
        self.next2Button.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return true
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onSkipPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
    
    }
}
