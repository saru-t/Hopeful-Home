//
//  HomeScreenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HomeScreenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleBlurView: UIView!
    @IBOutlet weak var overlayView: UIView!
    @IBOutlet weak var labelLabel: UILabel!
    @IBOutlet weak var labelTwoLabel: UILabel!
    @IBOutlet weak var labelThreeLabel: UILabel!
    @IBOutlet weak var xLabel: UILabel!
    @IBOutlet weak var πLabel: UILabel!
    @IBOutlet weak var welcomeLabel: SupernovaLabel!
    @IBOutlet weak var rectangleTwoBlurView: UIView!
    @IBOutlet weak var duringTheseUnknowiLabel: UILabel!
    @IBOutlet weak var rectangleView: UIView!
    @IBOutlet weak var sendUsFeedbackToLabel: UILabel!
    @IBOutlet weak var clickToReturnToCLabel: UILabel!
    @IBOutlet weak var rectangleTwoView: UIView!
    @IBOutlet weak var xButton: SupernovaButton!
    @IBOutlet weak var havenLabel: UILabel!
    @IBOutlet weak var homeLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var librariesLabel: UILabel!
    @IBOutlet weak var shapeView: UIView!
    @IBOutlet weak var ovalView: UIView!
    @IBOutlet weak var ovalTwoView: UIView!
    @IBOutlet weak var ovalThreeView: UIView!
    @IBOutlet weak var ovalFourView: UIView!
    @IBOutlet weak var rectangleThreeView: UIView!
    private var allGradientLayers: [CAGradientLayer] = []


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleBlurView
        self.rectangleBlurView.layer.cornerRadius = 6
        self.rectangleBlurView.layer.masksToBounds = true
        
        // Setup overlayView
        let overlayViewGradient = CAGradientLayer()
        overlayViewGradient.colors = [UIColor(red: 1, green: 1, blue: 1, alpha: 1).cgColor /* #FFFFFF */, UIColor(red: 0.847, green: 0.847, blue: 0.847, alpha: 0).cgColor /* #D8D8D8 */]
        overlayViewGradient.locations = [0, 1]
        overlayViewGradient.startPoint = CGPoint(x: 0.5, y: 0.778)
        overlayViewGradient.endPoint = CGPoint(x: 0.5, y: 1.511)
        overlayViewGradient.frame = self.overlayView.bounds
        self.overlayView.layer.insertSublayer(overlayViewGradient, at: 0)
        self.allGradientLayers.append(overlayViewGradient)
        
        
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: "3", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup labelTwoLabel
        let labelTwoLabelAttrString = NSMutableAttributedString(string: "7", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelTwoLabel.attributedText = labelTwoLabelAttrString
        
        // Setup labelThreeLabel
        let labelThreeLabelAttrString = NSMutableAttributedString(string: "5", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.labelThreeLabel.attributedText = labelThreeLabelAttrString
        
        // Setup xLabel
        let xLabelAttrString = NSMutableAttributedString(string: "2", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.xLabel.attributedText = xLabelAttrString
        
        // Setup πLabel
        let πLabelAttrString = NSMutableAttributedString(string: "1", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.πLabel.attributedText = πLabelAttrString
        
        // Setup welcomeLabel
        let welcomeLabelAttrString = NSMutableAttributedString(string: "Welcome", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 36)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.welcomeLabel.attributedText = welcomeLabelAttrString
        
        // Setup rectangleTwoBlurView
        self.rectangleTwoBlurView.layer.cornerRadius = 6
        self.rectangleTwoBlurView.layer.masksToBounds = true
        
        // Setup duringTheseUnknowiLabel
        let duringTheseUnknowiLabelAttrString = NSMutableAttributedString(string: "During these unknowing times, domestic abuse and abuse in general has rocketed to its peaks, to the point where helplines are being called 700% more. This is due to our current lockdown and stressful situations and more arguments that are taking place in the household.\nHopeful Home works towards making everyone’s house a safe and a healthy place to work and live, with the outside world not being safe anymore, we aim to make the home a safe environment for as many as we can.\nTake a look at our many features that we have to make you stronger day by day. Talk to Haven - the chatbot. Read our information on safety plans and legalities to empower yourself. Feed yourself from the many positive quotes we have on the app. Chat to our ai bots, to feel comforted and not alone.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 16)!,
            .foregroundColor : UIColor(red: 0.61, green: 0.61, blue: 0.61, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.duringTheseUnknowiLabel.attributedText = duringTheseUnknowiLabelAttrString
        
        // Setup rectangleView
        self.rectangleView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.rectangleView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleView.layer.shadowRadius = 4
        self.rectangleView.layer.shadowOpacity = 1
        
        self.rectangleView.layer.borderColor = UIColor(red: 0.471, green: 0.624, blue: 0.8, alpha: 1).cgColor /* #789FCC */
        self.rectangleView.layer.borderWidth = 2
        
        
        // Setup sendUsFeedbackToLabel
        let sendUsFeedbackToLabelAttrString = NSMutableAttributedString(string: "Send us Feedback \nto help improve our app!", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.54,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.sendUsFeedbackToLabel.attributedText = sendUsFeedbackToLabelAttrString
        
        // Setup clickToReturnToCLabel
        let clickToReturnToCLabelAttrString = NSMutableAttributedString(string: "Click to Return to Calculator", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.clickToReturnToCLabel.attributedText = clickToReturnToCLabelAttrString
        
        // Setup rectangleTwoView
        self.rectangleTwoView.layer.borderColor = UIColor(red: 0.29, green: 0.29, blue: 0.29, alpha: 1).cgColor /* #4A4A4A */
        self.rectangleTwoView.layer.borderWidth = 4
        
        self.rectangleTwoView.layer.cornerRadius = 6
        self.rectangleTwoView.layer.masksToBounds = true
        
        // Setup xButton
        self.xButton.snImageTextSpacing = 10
        
        // Setup havenLabel
        let havenLabelAttrString = NSMutableAttributedString(string: "Haven", attributes: [
            .font : UIFont.systemFont(ofSize: 10),
            .foregroundColor : UIColor(red: 0.56, green: 0.56, blue: 0.58, alpha: 1),
            .kern : 0.3,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.havenLabel.attributedText = havenLabelAttrString
        
        // Setup homeLabel
        let homeLabelAttrString = NSMutableAttributedString(string: "Home", attributes: [
            .font : UIFont.systemFont(ofSize: 11),
            .foregroundColor : UIColor(red: 0.56, green: 0.56, blue: 0.58, alpha: 1),
            .kern : 0.33,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.homeLabel.attributedText = homeLabelAttrString
        
        // Setup infoLabel
        let infoLabelAttrString = NSMutableAttributedString(string: "Info", attributes: [
            .font : UIFont.systemFont(ofSize: 10),
            .foregroundColor : UIColor(red: 0.56, green: 0.56, blue: 0.58, alpha: 1),
            .kern : 0.3,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.infoLabel.attributedText = infoLabelAttrString
        
        // Setup librariesLabel
        let librariesLabelAttrString = NSMutableAttributedString(string: "Libraries", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 10)!,
            .foregroundColor : UIColor(red: 0, green: 0.48, blue: 1, alpha: 1),
            .kern : 0.3,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.librariesLabel.attributedText = librariesLabelAttrString
        
        // Setup shapeView
        self.shapeView.layer.cornerRadius = 2.5
        self.shapeView.layer.masksToBounds = true
        
        // Setup ovalView
        self.ovalView.layer.borderColor = UIColor(red: 0.309, green: 0.625, blue: 0.729, alpha: 1).cgColor /* #4F9FBA */
        self.ovalView.layer.borderWidth = 3
        
        self.ovalView.layer.cornerRadius = 11.5
        self.ovalView.layer.masksToBounds = true
        
        // Setup ovalTwoView
        self.ovalTwoView.layer.cornerRadius = 1.5
        self.ovalTwoView.layer.masksToBounds = true
        
        // Setup ovalThreeView
        self.ovalThreeView.layer.cornerRadius = 1.5
        self.ovalThreeView.layer.masksToBounds = true
        
        // Setup ovalFourView
        self.ovalFourView.layer.cornerRadius = 1.5
        self.ovalFourView.layer.masksToBounds = true
        
        // Setup rectangleThreeView
        self.rectangleThreeView.layer.borderColor = UIColor(red: 0.31, green: 0.624, blue: 0.729, alpha: 1).cgColor /* #4F9FBA */
        self.rectangleThreeView.layer.borderWidth = 3
        
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Layout

    override public func viewDidLayoutSubviews()  {
        super.viewDidLayoutSubviews()
        for layer in self.allGradientLayers {
            layer.frame = layer.superlayer?.frame ?? CGRect.zero
        }
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onXPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Home Screen", sender: nil)
    }
}
