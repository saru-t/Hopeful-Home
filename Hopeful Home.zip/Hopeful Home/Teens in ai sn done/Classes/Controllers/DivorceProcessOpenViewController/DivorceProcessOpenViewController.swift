//
//  DivorceProcessOpenViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class DivorceProcessOpenViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var thereAre4SimpleSLabel: UILabel!
    @IBOutlet weak var decreeNisiTheDeLabel: UILabel!
    @IBOutlet weak var decreeAbsoluteThLabel: UILabel!
    @IBOutlet weak var buttonButton: SupernovaButton!
    @IBOutlet weak var leftButton: SupernovaButton!
    @IBOutlet weak var legalInformationDLabel: SupernovaLabel!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup thereAre4SimpleSLabel
        let thereAre4SimpleSLabelAttrString = NSMutableAttributedString(string: "There are 4 simple steps that need to be taken if the abuser is your partner.\n\nStep 1: Application for divorce - includes questionnaire - Will be your divorce petition\n\nStep 2:Acknowledgement of Service\n\nStep 3:In effect, an application for a Decree Nisi is simply the process of asking the Court to place your Divorce Petition and supporting documentation before a Judge in order for him or her to consider whether to grant your divorce.\nYour case manager will complete all relevant Decree Nisi forms and documentation on your behalf; helping you progress to the final stage of your divorce quickly and with a minimum amount of stress.\n\nStage 4 - Application for Decree Absolute\nAfter the declaration of your Decree Nisi, you will need to wait a further six weeks and one day, after which you are entitled to apply for a Decree Absolute.\nFollowing the submission of this application to the Divorce Centre, your case manager or solicitor will then submit your application for Decree Absolute to the Divorce Centre on your behalf. The Court will then declare your marriage dissolved.\n\nAlthough most domestic victims do get their right of way when they have opposed an abusive relationship, many people also take advantage and falsely accuse others of being abusive. If you are being falsely accused of committing an act of domestic violence, it usually happens because of an intention to defame the accused, or a miscommunication between parties during a confrontation. In some cases, a legitimate act of self-defense can be misconstrued as an act to deliberately hurt another person. - You could also take the other person to court. To find out more, visit the website links below.\n\n\nThe police have started to take this sort of abuse seriously as well and there is now also a law against it. For more information on anything please visit the websites linked below as those are the sources of information from which we have gained our knowledge.\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.thereAre4SimpleSLabel.attributedText = thereAre4SimpleSLabelAttrString
        
        // Setup decreeNisiTheDeLabel
        let decreeNisiTheDeLabelAttrString = NSMutableAttributedString(string: "Decree Nisi - The decree nisi is a provisional decree of divorce pronounced when the court is satisfied that a person has met the legal and procedural requirements to obtain a divorce. Following the pronouncement of decree nisi, the marriage still exists and you are not yet 'divorced'.", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.decreeNisiTheDeLabel.attributedText = decreeNisiTheDeLabelAttrString
        
        // Setup decreeAbsoluteThLabel
        let decreeAbsoluteThLabelAttrString = NSMutableAttributedString(string: "Decree Absolute - The decree absolute is a court-issued document that legally ends your marriage and concludes divorce proceedings.", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.decreeAbsoluteThLabel.attributedText = decreeAbsoluteThLabelAttrString
        
        // Setup buttonButton
        self.buttonButton.snImageTextSpacing = 10
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
        // Setup legalInformationDLabel
        let legalInformationDLabelAttrString = NSMutableAttributedString(string: "Legal Information: Divorce Process\n", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 36)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.legalInformationDLabel.attributedText = legalInformationDLabelAttrString
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onbuttonPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Divorce Process Closed", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Closed", sender: nil)
    }
}
