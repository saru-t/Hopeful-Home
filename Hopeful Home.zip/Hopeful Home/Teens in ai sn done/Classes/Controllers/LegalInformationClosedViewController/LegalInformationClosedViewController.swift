//
//  LegalInformationClosedViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class LegalInformationClosedViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var divorceProcessButton: SupernovaButton!
    @IBOutlet weak var openDropDownMenusLabel: UILabel!
    @IBOutlet weak var bitmapButton: SupernovaButton!
    @IBOutlet weak var bitmapTwoButton: SupernovaButton!
    @IBOutlet weak var bitmapThreeButton: SupernovaButton!
    @IBOutlet weak var bitmapFourButton: SupernovaButton!
    @IBOutlet weak var legalInformationLabel: SupernovaLabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup divorceProcessButton
        self.divorceProcessButton.layer.cornerRadius = 12
        self.divorceProcessButton.layer.masksToBounds = true
        self.divorceProcessButton.snImageTextSpacing = 10
        
        // Setup openDropDownMenusLabel
        let openDropDownMenusLabelAttrString = NSMutableAttributedString(string: "Open drop down menus by clicking ", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0.47, green: 0.62, blue: 0.8, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.openDropDownMenusLabel.attributedText = openDropDownMenusLabelAttrString
        
        // Setup bitmapButton
        self.bitmapButton.snImageTextSpacing = 10
        
        // Setup bitmapTwoButton
        self.bitmapTwoButton.snImageTextSpacing = 10
        
        // Setup bitmapThreeButton
        self.bitmapThreeButton.snImageTextSpacing = 10
        
        // Setup bitmapFourButton
        self.bitmapFourButton.snImageTextSpacing = 10
        
        // Setup legalInformationLabel
        let legalInformationLabelAttrString = NSMutableAttributedString(string: "Legal Information", attributes: [
            .font : UIFont.systemFont(ofSize: 36),
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : 0,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 40, paragraphSpacing: 0)
        ])
        self.legalInformationLabel.attributedText = legalInformationLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onGroup17Pressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Divorce Process Closed", sender: nil)
    }

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Open", sender: nil)
    }

    @IBAction public func onBitmapTwoPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Open Two", sender: nil)
    }

    @IBAction public func onBitmapThreePressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Open Three", sender: nil)
    }

    @IBAction public func onBitmapFourPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Legal Information Open Four", sender: nil)
    }

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Helpful Information", sender: nil)
    }
}
