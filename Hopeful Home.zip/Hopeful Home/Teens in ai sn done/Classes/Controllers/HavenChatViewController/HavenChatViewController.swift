//
//  HavenChatViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class HavenChatViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var labelLabel: UILabel!
    @IBOutlet weak var messageTextLabel: UILabel!
    @IBOutlet weak var messageTextTwoLabel: UILabel!
    @IBOutlet weak var messageTextThreeLabel: UILabel!
    @IBOutlet weak var messageTextFourLabel: UILabel!
    @IBOutlet weak var messageTextFiveLabel: UILabel!
    @IBOutlet weak var messageTextSixLabel: UILabel!
    @IBOutlet weak var messageTextSevenLabel: UILabel!
    @IBOutlet weak var messageTextEightLabel: UILabel!
    @IBOutlet weak var shapeView: UIView!
    @IBOutlet weak var messageTextNineLabel: UILabel!
    @IBOutlet weak var leftButton: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup labelLabel
        let labelLabelAttrString = NSMutableAttributedString(string: " ", attributes: [
            .font : UIFont.systemFont(ofSize: 17),
            .foregroundColor : UIColor(red: 0, green: 0.48, blue: 1, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.labelLabel.attributedText = labelLabelAttrString
        
        // Setup messageTextLabel
        let messageTextLabelAttrString = NSMutableAttributedString(string: "Thank you Haven", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextLabel.attributedText = messageTextLabelAttrString
        
        // Setup messageTextTwoLabel
        let messageTextTwoLabelAttrString = NSMutableAttributedString(string: "Haven Define: A place of safety.", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextTwoLabel.attributedText = messageTextTwoLabelAttrString
        
        // Setup messageTextThreeLabel
        let messageTextThreeLabelAttrString = NSMutableAttributedString(string: "Hi", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextThreeLabel.attributedText = messageTextThreeLabelAttrString
        
        // Setup messageTextFourLabel
        let messageTextFourLabelAttrString = NSMutableAttributedString(string: "Hi, I’m Haven!", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextFourLabel.attributedText = messageTextFourLabelAttrString
        
        // Setup messageTextFiveLabel
        let messageTextFiveLabelAttrString = NSMutableAttributedString(string: "Good to see you again! You’re braver than you believe, and stronger than you seem and smarter than you think.", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextFiveLabel.attributedText = messageTextFiveLabelAttrString
        
        // Setup messageTextSixLabel
        let messageTextSixLabelAttrString = NSMutableAttributedString(string: "How can I stay positive ", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextSixLabel.attributedText = messageTextSixLabelAttrString
        
        // Setup messageTextSevenLabel
        let messageTextSevenLabelAttrString = NSMutableAttributedString(string: "At any point, just say bye and i’ll leave you to have a good day", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextSevenLabel.attributedText = messageTextSevenLabelAttrString
        
        // Setup messageTextEightLabel
        let messageTextEightLabelAttrString = NSMutableAttributedString(string: "Praesent erat lorem", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 1, green: 1, blue: 1, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .right, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextEightLabel.attributedText = messageTextEightLabelAttrString
        
        // Setup shapeView
        self.shapeView.layer.cornerRadius = 2.5
        self.shapeView.layer.masksToBounds = true
        
        // Setup messageTextNineLabel
        let messageTextNineLabelAttrString = NSMutableAttributedString(string: "1 way to stay positive is to do a kind act everyday. Kindness boosts happiness. Ask Haven again for ‘How can I stay positive?’ and Haven can try to give you another way", attributes: [
            .font : UIFont(name: "LucidaGrande-Bold", size: 17)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : -0.41,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .left, lineHeight: 22, paragraphSpacing: 0)
        ])
        self.messageTextNineLabel.attributedText = messageTextNineLabelAttrString
        
        // Setup leftButton
        self.leftButton.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return false
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onLeftPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Haven Info", sender: nil)
    }
}
