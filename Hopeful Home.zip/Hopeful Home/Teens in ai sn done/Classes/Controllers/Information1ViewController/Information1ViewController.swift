//
//  Information1ViewController.swift
//  Teens in ai sn done
//
//  Created by [Author].
//  Copyright © 2018 [Company]. All rights reserved.
//

// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Import

import UIKit


// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
// MARK: - Implementation

class Information1ViewController: UIViewController {


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Properties

    @IBOutlet weak var rectangleView: UIView!
    @IBOutlet weak var importantInformatioLabel: UILabel!
    @IBOutlet weak var welcomeToHopefulHLabel: UILabel!
    @IBOutlet weak var skipButton: SupernovaButton!
    @IBOutlet weak var next1Button: SupernovaButton!


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Lifecycle

    override public func viewDidLoad()  {
        super.viewDidLoad()
        self.setupComponents()
        self.setupUI()
        self.setupGestureRecognizers()
        self.setupLocalization()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override public func viewWillAppear(_ animated: Bool)  {
        super.viewWillAppear(animated)
        
        // Navigation bar, if any
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Setup

    private func setupComponents()  {
        // Setup rectangleView
        self.rectangleView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor /* #000000 */
        self.rectangleView.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.rectangleView.layer.shadowRadius = 4
        self.rectangleView.layer.shadowOpacity = 1
        
        self.rectangleView.layer.borderColor = UIColor(red: 0.686, green: 0.788, blue: 0.812, alpha: 1).cgColor /* #AFC9CF */
        self.rectangleView.layer.borderWidth = 4
        
        
        // Setup importantInformatioLabel
        let importantInformatioLabelAttrString = NSMutableAttributedString(string: "Important Information", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 34)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.37,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.importantInformatioLabel.attributedText = importantInformatioLabelAttrString
        
        // Setup welcomeToHopefulHLabel
        let welcomeToHopefulHLabelAttrString = NSMutableAttributedString(string: "Welcome to Hopeful Home! We aim to make every house a haven.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHopeful Home is disguised as a calculator app. Which functions. However if you click ’See Past Calculations’ and click ‘π’ you will enter the app.\n\n\n\n ", attributes: [
            .font : UIFont(name: "LucidaGrande", size: 18)!,
            .foregroundColor : UIColor(red: 0, green: 0, blue: 0, alpha: 1),
            .kern : 0.2,
            .paragraphStyle : NSMutableParagraphStyle(alignment: .center, lineHeight: nil, paragraphSpacing: 0)
        ])
        self.welcomeToHopefulHLabel.attributedText = welcomeToHopefulHLabelAttrString
        
        // Setup skipButton
        self.skipButton.snImageTextSpacing = 10
        
        // Setup next1Button
        self.next1Button.snImageTextSpacing = 10
        
    }

    private func setupUI()  {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }

    private func setupGestureRecognizers()  {
    
    }

    private func setupLocalization()  {
    
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Status Bar

    override public var prefersStatusBarHidden: Bool  {
        return true
    }

    override public var preferredStatusBarStyle: UIStatusBarStyle  {
        return .default
    }


    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 
    // MARK: - Actions

    @IBAction public func onSkipPressed(_ sender: UIButton)  {
    
    }

    @IBAction public func onBitmapPressed(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "Push Information 2", sender: nil)
    }
}
